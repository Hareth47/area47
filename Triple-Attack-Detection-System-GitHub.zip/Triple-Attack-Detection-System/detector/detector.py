#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Triple Attack Detection System - Python Detector
==================================================
يكتشف: UDP Flood / TCP SYN Flood / Port Scanning
ويرسل التنبيهات إلى NodeMCU (ESP8266) عبر HTTP.

⚠️ شغّل هذا السكربت كمسؤول (Administrator).
"""

import time
import threading
from collections import defaultdict, deque

import requests
from scapy.all import sniff, IP, TCP, UDP

# ============================================================
# ⚙️ الإعدادات الرئيسية
# ============================================================
ESP_IP  = "192.168.1.100"  # Replace with the IP address printed by your ESP8266
ESP_URL = f"http://{ESP_IP}/alert"

# ⚠️ اسم واجهة Wi-Fi على جهازك (مهم جداً)
NETWORK_INTERFACE = "Wi-Fi"  # Replace with your actual capture interface name

# ============================================================
# 🎯 حدود الكشف
# ============================================================
WINDOW_SECONDS = 1              # نافذة التحليل الزمنية

UDP_THRESHOLD       = 800       # حزم UDP في الثانية
SYN_THRESHOLD       = 100       # حزم SYN في الثانية
PORT_SCAN_THRESHOLD = 15        # عدد المنافذ المختلفة

# ============================================================
# ⏱️ فترات التنبيه
# ============================================================
ALERT_COOLDOWN = 3              # انتظار بين التنبيهات
RESET_AFTER    = 5              # العودة إلى SECURE

# ============================================================
# 📦 بنى البيانات
# ============================================================
udp_window       = deque()
syn_window       = deque()
port_scan_window = defaultdict(deque)
lock             = threading.Lock()

last_alert_time = {
    "UDP_FLOOD": 0,
    "SYN_FLOOD": 0,
    "PORT_SCAN": 0,
}

current_state = "SECURE"
state_lock    = threading.Lock()


# ============================================================
# 🧹 دوال مساعدة
# ============================================================
def cleanup_window(window, now):
    """إزالة العناصر القديمة من النافذة الزمنية."""
    while window and now - window[0][0] > WINDOW_SECONDS:
        window.popleft()


def send_alert(attack_type, rate=0, src_ip="---"):
    """إرسال تنبيه إلى NodeMCU مع cooldown."""
    global current_state
    now = time.time()

    if now - last_alert_time[attack_type] < ALERT_COOLDOWN:
        return
    last_alert_time[attack_type] = now

    payload = {
        "type": attack_type,
        "rate": rate,
        "src_ip": src_ip,
        "timestamp": int(now)
    }

    try:
        r = requests.post(ESP_URL, json=payload, timeout=2)
        print(f"[ALERT] {attack_type} rate={rate} src={src_ip} -> HTTP {r.status_code}")

        # عرض رد ESP8266
        try:
            resp = r.json()
            print(f"        ESP: total={resp.get('total')} "
                  f"udp={resp.get('udp')} syn={resp.get('syn')} "
                  f"scan={resp.get('scan')} per_min={resp.get('per_min')}")
        except Exception:
            pass

        with state_lock:
            current_state = attack_type

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] فشل الاتصال بـ NodeMCU: {e}")


def reset_to_secure():
    """إعادة NodeMCU إلى الحالة الطبيعية."""
    global current_state
    try:
        payload = {"type": "SECURE", "timestamp": int(time.time())}
        requests.post(ESP_URL, json=payload, timeout=2)
        with state_lock:
            current_state = "SECURE"
        print("[INFO] العودة إلى SECURE")
    except requests.exceptions.RequestException:
        pass


# ============================================================
# 🔬 محلل الحزم
# ============================================================
def analyze_packet(pkt):
    now = time.time()

    # ---------- UDP Flood ----------
    if IP in pkt and UDP in pkt:
        with lock:
            udp_window.append((now, pkt[IP].src))
            cleanup_window(udp_window, now)
            count = len(udp_window)

        if count > UDP_THRESHOLD:
            print(f"[DETECT] UDP Flood: {count} pkt/s")
            send_alert("UDP_FLOOD", rate=count, src_ip=pkt[IP].src)
        return

    # ---------- TCP ----------
    if IP in pkt and TCP in pkt:
        src_ip   = pkt[IP].src
        dst_port = pkt[TCP].dport
        flags    = pkt[TCP].flags

        # SYN Flood: SYN=1 و ACK=0
        if flags & 0x02 and not (flags & 0x10):
            with lock:
                syn_window.append((now, src_ip))
                cleanup_window(syn_window, now)
                syn_count = len(syn_window)

            if syn_count > SYN_THRESHOLD:
                print(f"[DETECT] SYN Flood: {syn_count} SYN/s")
                send_alert("SYN_FLOOD", rate=syn_count, src_ip=src_ip)

        # Port Scan: تتبع المنافذ المختلفة من نفس المصدر
        with lock:
            window = port_scan_window[src_ip]
            window.append((now, dst_port))
            cleanup_window(window, now)
            unique_ports = len(set(p for _, p in window))

        if unique_ports > PORT_SCAN_THRESHOLD:
            print(f"[DETECT] Port Scan from {src_ip}: {unique_ports} ports")
            send_alert("PORT_SCAN", rate=unique_ports, src_ip=src_ip)


# ============================================================
# 🔄 خيط مراقبة الحالة
# ============================================================
def state_monitor():
    while True:
        time.sleep(1)
        with state_lock:
            state = current_state
        if state != "SECURE":
            latest = max(last_alert_time.values())
            if time.time() - latest > RESET_AFTER:
                reset_to_secure()


# ============================================================
# 🚀 نقطة البداية
# ============================================================
def main():
    print("=" * 60)
    print("   Triple Attack Detection System - Python Detector")
    print("=" * 60)
    print(f"   Interface         : {NETWORK_INTERFACE}")
    print(f"   NodeMCU URL       : {ESP_URL}")
    print(f"   UDP Threshold     : {UDP_THRESHOLD} pkt/s")
    print(f"   SYN Threshold     : {SYN_THRESHOLD} pkt/s")
    print(f"   Port Scan Thresh  : {PORT_SCAN_THRESHOLD} ports/s")
    print("=" * 60)
    print("   اضغط Ctrl+C للإيقاف\n")

    # تشغيل خيط المراقبة
    threading.Thread(target=state_monitor, daemon=True).start()

    try:
        sniff(
            iface=NETWORK_INTERFACE,
            prn=analyze_packet,
            store=False,
            filter="udp or tcp"
        )
    except KeyboardInterrupt:
        print("\n[INFO] إيقاف...")
        reset_to_secure()
    except PermissionError:
        print("[ERROR] شغّل السكربت كمسؤول (Administrator).")
    except Exception as e:
        print(f"[ERROR] {e}")


if __name__ == "__main__":
    main()